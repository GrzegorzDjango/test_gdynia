from setuptools import setup, find_packages

setup(
    name='rumpelstiltskin',
    version='0.71',
    package_dir={'': 'src'},
    packages=find_packages(where='src'),
)
