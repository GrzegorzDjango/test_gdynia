# Rumpelstiltskin :smiling_imp:

The ETL imp that spins straw into gold.

This is the core pipeline that implements GCP AI Engine's custom predictor Pipeline and Predictor classes for the Rumpelstiltskin feature.

For **model documentation** check out [Model_Documentation_Jan2020.ipynb](./Model_Documentation_Jan2020.ipynb).

## Getting Started

These instructions will get you a copy of the project up and running on your local machine for development and testing purposes. See deployment for notes on how to deploy the project on a live system.

1. This project uses Python `3.5.3` - you should have it available as your interpreter. [how to](#python-install)
2. Ensure you have [`pip`](https://pip.pypa.io) available on your system.
3. Also be sure to install [pipenv](https://github.com/pypa/pipenv). You can do it like `pip install pipenv`.

### Local Setup

We can use pipenv for great good. In your terminal (this is for Linux):

```bash
# generates lockfile then installs dependencies
pipenv update
```

If you're using IntelliJ, you can also just set up your project interpreter through the settings.

![IntelliJ-Pycharm-Interpreter](./docs/IntelliJ-New-Interpreter-Pipenv.png)

## Running Tests

// TODO

## Manual Testing CSV Data on Deployed Model

Should work with any of Ivy's real estate CSVs, but the output may look like crap if the model hasn't been conditioned to work with certain kinds of data. Use at your own discretion.

**In GCP's web interface, go to the AI Platform Model's menu to see the list of models currently deployed**

![GCP Models Menu](./docs/gcp_models_menu.png)

**Pick the model version you are interested in testing**

![GCP Model Test & Use](./docs/gcp_models_menu2.png)

**Copy the text data out of your CSV**

![Copy text from CSV](./docs/gcp_models_menu3.png)

**Stringify the CSV text**

https://onlinetexttools.com/json-stringify-text

![Stringify website](./docs/gcp_models_menu4.png)

**Copy the stringified text into the JSON { "instances" : [ stringifiedtextgoeshere ] } in the model's test box and hit TEST**

![GCP Models Menu](./docs/gcp_models_menu5.png)

**VOILA! You get the predictions as a JSON! (but you have to copy it to get it out)**

* Note that model output will vary while models are in development, and across model versions. Not every one will give predictions as shown.
* also note that anything that happens to data in production happens to this data, such as saving to databases when that feature is running. As a result, once models are production ready, please use this sparingly.

## Deployment

This code is designed to work with Google's AI Platform. Here's how to deploy and use it:

### Create New Distribution:

1. Update the Version Number in `setup.py`

2. Create a dist package

```bash
python setup.py sdist --formats=gztar
```

3. copy the tar.gz to the gcp folder

```bash
gcloud (TODO)
```

https://console.cloud.google.com/storage/browser/ivy-rumpel-models/pipelines?project=ivy-re-data

### To use a pipeline distribution in model & workflow development

* copy the code in the `pipeline` folder to the `pipeline` folder in the workflow template and then use as-is,or extract the files from the distribution package
* https://github.com/ivy-re-tech/rumpelstiltskin-workflow-template/tree/updates/src  (link subject to change)

To use distribution in a new model version deployment

* (wip) update the workflow template Makefile so that it deploys with your preferred pipeline's tar.gz filename
* https://github.com/ivy-re-tech/rumpelstiltskin-workflow-template/tree/updates/ (link subject to change)

## Built With

* [Pandas](https://pandas.pydata.org/) - Python Data Analysis Library
* [scikit-learn](https://scikit-learn.org/) - Machine Learning in Python

## Contributing

// TODO

## Versioning

We use [SemVer](http://semver.org/) (loosely) for versioning. For the versions available, see the [tags on this repository](https://github.com/your/project/tags). 

## Authors

* **Ben Hamilton** - data mage
* **Andrei Ivasiuc** - polyglot problem solver

## License

This project is proprietary.

## Acknowledgments

* This README format was inspired by Billie Thompson's [gist](https://gist.github.com/PurpleBooth/109311bb0361f32d87a2).
* Emoji list by [rxaviers](https://gist.github.com/rxaviers/7360908).

---

### Python Install

Here's the Debian example (Ubuntu) for compiling Python 3.5.3 from source.
You could also use the `deadsnakes` PPA and `apt-get` - Google that.

```bash
wget https://www.python.org/ftp/python/3.5.3/Python-3.5.3.tgz
tar xvf Python-3.5.3.tgz
cd Python-3.5.3
./configure --enable-optimizations --disable-profiling
make
sudo make altinstall
python3.5
```