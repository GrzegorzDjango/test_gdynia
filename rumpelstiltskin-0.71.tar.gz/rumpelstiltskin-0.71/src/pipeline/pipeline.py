import os
import workflow

DEFAULT_STATE = {"data": {}, "artifacts": {}}


class Pipeline:
    def __init__(self, state):
        self._state = state

    def _import_step(self, step):
        step_name = "{}.{}".format("workflow", step)
        return __import__(step_name, fromlist=["execute"])

    def get_data_layer(self, layer):
        return self._state["data"][layer]

    def set_data_layer(self, layer, data):
        self._state["data"][layer] = data

    def get_artifact(self, artifact):
        return self._state["artifacts"][artifact]

    def run(self):
        for step in workflow.steps:
            module = self._import_step(step)
            executor = getattr(module, "execute")
            executor(self)
        return self.get_data_layer("output")
