import os
import pickle
from pipeline.pipeline import Pipeline


class Predictor:

    def __init__(self, state):
        self._state = state
        self._pipeline = Pipeline(self._state)

    def predict(self, instances, **kwargs):
        self._pipeline.set_data_layer("init", instances)
        self._pipeline.set_data_layer("hints", {} )   # kwargs["hints"])
        return self._pipeline.run()

    @classmethod
    def from_path(cls, model_dir):
        """Loads model from CloudStorage"""
        state = {
            "data": {},
            "artifacts": {}
        }
        for artifact in os.listdir(model_dir):
            artifact_path = os.path.join(model_dir, artifact)
            with open(artifact_path, 'rb') as f:
                state["artifacts"][artifact] = pickle.load(f)
        return cls(state)
